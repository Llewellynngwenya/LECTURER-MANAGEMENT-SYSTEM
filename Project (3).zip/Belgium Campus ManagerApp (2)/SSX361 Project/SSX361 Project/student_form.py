
import tkinter as tk
from tkinter import messagebox, Listbox, Scrollbar, ttk
import student_create as sc
import student_insert as si
import student_update as su
import student_read as sr
import student_delete as sd

def animate_label(label, color1, color2, delay):
    """Animate label color alternation."""
    label.config(foreground=color1)
    label.after(delay, lambda: animate_label(label, color2, color1, delay))

class StudentForm(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Student Form")
        self.geometry("700x500")
        self.config(bg="#ADD8E6")  # Blue themed background


        welcome_label = ttk.Label(self, text="Student Details", font=("Arial", 24, "bold"), foreground="white",
                                  background="#87CEEB")
        welcome_label.pack()
        animate_label(welcome_label, "blue", "white", 1000)

        # Define StringVar variables for input fields
        self.name_var = tk.StringVar()
        self.surname_var = tk.StringVar()
        self.age_var = tk.StringVar()
        self.student_number_var = tk.StringVar()
        self.course_var = tk.StringVar()

        # Create a frame to hold the widgets
        self.frame = tk.Frame(self, bg="#ADD8E6")  # Blue themed background
        self.frame.pack(expand=True, fill=tk.BOTH)

        # Labels and Entry widgets for student details
        tk.Label(self.frame, text="Name:", font = ('bold',14) ,bg="#ADD8E6").grid(row=0, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.name_var).grid(row=0, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Surname:", font = ('bold', 14), bg="#ADD8E6").grid(row=1, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.surname_var).grid(row=1, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Age:", font = ('bold', 14), bg="#ADD8E6").grid(row=2, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.age_var).grid(row=2, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Student Number:",font = ('bold', 14), bg="#ADD8E6").grid(row=3, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.student_number_var).grid(row=3, column=1, padx=10, pady=5)

        tk.Label(self.frame, text="Course:", font = ('bold', 14), bg="#ADD8E6").grid(row=4, column=0, padx=10, pady=5)
        tk.Entry(self.frame, textvariable=self.course_var).grid(row=4, column=1, padx=10, pady=5)

        

        # Listbox to display student details
        self.listbox = Listbox(self.frame, width=70, height=10)
        self.listbox.grid(row=5, columnspan=2, padx=10, pady=5)


        scrollbar = Scrollbar(self.frame, orient="vertical")
        scrollbar.config(command=self.listbox.yview)
        scrollbar.grid(row=5, column=2, sticky="ns")
        self.listbox.config(yscrollcommand=scrollbar.set)

        # Load existing students
        self.load_students()

        # Buttons for CRUD operations
        add_btn = tk.Button(self.frame, text="Add", font = 'bold', command=self.add_student, bg="#FFB6C1")  # Light pink button
        add_btn.grid(row=6, column=0, padx=10, pady=5)

        update_btn = tk.Button(self.frame, text="Update", font = 'bold', command=self.update_student, bg="#FFB6C1")  # Light pink button
        update_btn.grid(row=6, column=1, padx=10, pady=5)

        delete_btn = tk.Button(self.frame, text="Delete", font = 'bold', command=self.delete_student, bg="#FFB6C1")  # Light pink button
        delete_btn.grid(row=7, column=0, padx=10, pady=5)

        clear_btn = tk.Button(self.frame, text="Clear", font ='bold', command=self.clear_student_listbox, bg="#FFB6C1")  # Light pink button
        clear_btn.grid(row=7, column=1, padx=10, pady=5)


    def clear_student_listbox(self):
        # Delete all items from the listbox
        self.listbox.delete(0, tk.END)
    def add_student(self):
        name = self.name_var.get()
        surname = self.surname_var.get()
        age = self.age_var.get()
        student_number = self.student_number_var.get()
        course = self.course_var.get()

        if name and surname and age and student_number and course:
            si.insert_students(name, surname, age, student_number, course)
            self.load_students()
            self.clear_fields()
        else:
            messagebox.showwarning("Warning", "Please fill in all fields.")



    def load_students(self):
        self.listbox.delete(0, tk.END)
        students = sr.retrieve_students()
        for student in students:
            self.listbox.insert(tk.END, f"{student[1]} {student[2]}, Age: {student[3]}, Student Number: {student[4]}, Course: {student[5]}")

    def update_student(self):
        selected_index = self.listbox.curselection()
        if selected_index:
            selected_student = self.listbox.get(selected_index)
            parts = selected_student.split(", ")
            id = parts[-1]
            name = self.name_var.get()
            surname = self.surname_var.get()
            age = self.age_var.get()
            student_number = self.student_number_var.get()
            course = self.course_var.get()

            if name and surname and age and student_number and course:
                su.update_student(id, name, surname, age, student_number, course)
                self.listbox.delete(selected_index)
                self.listbox.insert(selected_index, f"{name},{surname},{age},{student_number},{course}")
                self.clear_fields()
            else:
                messagebox.showwarning("Warning", "Please fill in all fields.")
        else:
            messagebox.showwarning("Warning", "Please select a student to update.")

    def delete_student(self):
        selected_index = self.listbox.curselection()
        if selected_index:
            selected_student = self.listbox.get(selected_index)
            parts = selected_student.split(", ")
            id = parts[-1]
            sd.delete_student(id)
            self.listbox.delete(selected_index)
            self.clear_fields()
        else:
            messagebox.showwarning("Warning", "Please select a student to delete.")

    def clear_fields(self):
        self.name_var.set("")
        self.surname_var.set("")
        self.age_var.set("")
        self.student_number_var.set("")
        self.course_var.set("")

if __name__ == "__main__":
    root = tk.Tk()
    app = StudentForm(root)
    root.mainloop()






